import 'package:intl/intl.dart';

class bill{
  final int? id;
  final String? Date;
  final String? LastReading;
  final int? kWH;
  final String? prevBill;
  final String? status;

  bill({
    this.id,
    this.Date,
    this.LastReading,
    this.kWH,
    this.prevBill,
    this.status
  }); 

  bill.fromMap(Map<String, dynamic> res)
      : id = res["id"],
        Date = DateFormat("dd-MM-yyyy").format(DateTime.parse(res["Date"].toString())),
        LastReading = res["LastReading"].toString(),
        kWH = int.parse(res["kWH"].toString()),
        prevBill = res["prevBill"].toString(),
        status = res["status"];

  Map<String, Object?> toMap() {
    return {'id':id,'Date': Date, 'LastReading': LastReading, 'kWH': kWH, 'prevBill': prevBill,"status": status};
  }
}