import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sqflitedemo/DataSource/datasource.dart';
import 'package:sqflitedemo/Models/bill.dart';
import 'package:sqflitedemo/db/DatabaseHandler.dart';

class DemoPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _DemoPage();
  }
}

class _DemoPage extends State<DemoPage> {
  late DatabaseHandler handler;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final LastReading = TextEditingController();
  final prevBill = TextEditingController();
  final kWH = TextEditingController();

  final columns = ['外送日期及時間', '姓名', '電話', '地址', '刪除', '更新'];

  List<bill> bills = [];
  DateTime DateCreated = DateTime.now();

  void reload() async {
    bills = await this.handler.retrieveBill();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    this.handler = DatabaseHandler();
    this.handler.initializeDB().whenComplete(() async {
      bills = await this.handler.retrieveBill();
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    MyData _data = MyData(
      bills,
      handler,
      deleteHandler: (bill) async {
        await handler.deleteBill(int.parse(bill.id.toString()));
        reload();
      },
      updateHandler: (bill) async {
        if (_formKey.currentState!.validate()) {
          await handler.editBill(
            int.parse(bill.id.toString()),
            LastReading.text.toString(),
            int.parse(kWH.text),
            prevBill.text.toString(),
          );
          reload();
        }
      },
    );
    return Column(
      children: <Widget>[
        Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(5.0),
                  height: 45,
                  child: CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.dateAndTime,
                    initialDateTime: DateTime.now(),
                    onDateTimeChanged: (DateTime newDateTime) {
                      DateCreated = newDateTime;
                    },
                    use24hFormat: false,
                    minuteInterval: 1,
                  ),
                ),
                TextFormField(
                  controller: LastReading,
                  decoration: const InputDecoration(hintText: '姓名'),
                  validator: (String? value) {
                    if (value == null || value.isEmpty) {
                      return '請輸入姓名!';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: kWH,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                    TextInputFormatter.withFunction((oldValue, newValue) {
                      try {
                        final text = newValue.text;
                        if (text.isNotEmpty) double.parse(text);
                        return newValue;
                      } catch (e) {}
                      return oldValue;
                    })
                  ],
                  decoration: const InputDecoration(hintText: '電話'),
                  validator: (String? value) {
                    if (value == null || value.isEmpty) {
                      return '請輸入電話';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: prevBill,
                  decoration: const InputDecoration(hintText: '地址'),
                  validator: (String? value) {
                    if (value == null || value.isEmpty) {
                      return '請輸入地址!';
                    }
                    return null;
                  },
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: ElevatedButton(
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        String response = '';
                        int res = await addBill(
                            DateCreated.toString(),
                            LastReading.text.toString(),
                            int.parse(kWH.text),
                            prevBill.text.toString());

                        reload();

                        if (res > 0) {
                          response = "訂單送出成功!";
                          LastReading.clear();
                          kWH.clear();
                          prevBill.clear();
                        } else {
                          response = "喔! 有錯誤! 回傳代碼:" + res.toString();
                        }
                      }
                    },
                    style: ElevatedButton.styleFrom(primary: Colors.red),
                    child: const Text('送出'),
                  ),
                ),
              ],
            )),
        Padding(
            padding: const EdgeInsets.symmetric(vertical: 5.0),
            child: IconButton(
              icon: Icon(Icons.refresh),
              onPressed: () async {
                bills = await this.handler.retrieveBill();
                setState(() {});
              },
            )),
        Column(
          children: [
            SizedBox(
              height: 5,
            ),
            PaginatedDataTable(
              columns: getColumns(columns),
              source: _data,
              columnSpacing: 60,
              horizontalMargin: 5,
              rowsPerPage: 5,
              showCheckboxColumn: false,
            )
          ],
        ),
      ],
    );
  }

  List<DataColumn> getColumns(List<String> columns) => columns
      .map((String column) => DataColumn(
            label: Text(column),
          ))
      .toList();

  Future<int> addBill(
    String dateTime,
    String lastreading,
    int kWH,
    String prevBill,
  ) async {
    bill _bill = bill(
      Date: dateTime,
      LastReading: lastreading,
      kWH: kWH,
      prevBill: prevBill,
      status: 'Active',
    );
    this.handler.updateStatus();
    return await this.handler.insertBill(_bill);
  }
}
