package com.example.sqflitedemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
